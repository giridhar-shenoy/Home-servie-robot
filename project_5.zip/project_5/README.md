# Project 5: Home Service Robot

In this project, a mobile robot is asked to navigate to a pick-up zone for picking 
up a green cube. After that, it moves while carrying the cube to the drop-off
zone position and drops the cube there.

## How it works
The mobile robot first drives around and scan the house using laser for generating 
a static map about this place, this is done by the gmapping node. Having the map, it uses odometry and laser data 
to localize itself with adaptive monte carlo localization (AMCL). Upon receiving 
a navigation goal, it plans forward the trajectory using Dijkstra's algorithm and 
navigate to the goal. 

## Description
The project consists of the following packages:
1. turtlebot package: This package hosts the files for bringing up the robot.

2. pickup_objects package: This package gives multiple goals to the robot and 
   using the adaptive monte carlo localization algorithm which is a probabilistic
   localization system for a robot moving in 2D. It implements the adaptive Monte 
   Carlo localization approach, which uses a particle filter to track the pose of a robot against a known map.

3. add_markers packgae: Add_markers package contains two node that sends objects to display in rviz.
   These are used to simulate the picking up and drop of action of the robot.
   The add_markers_alone node can be used to visualise the objects without moving the robot.
   The add_markers node can be used to simulate picking up and drop off action as it subscribes the 
   odometry topic to know if the goal positions are reached.

4. Slam_gmapping: This package is used by the turtlebot package to generate a grid map by subscribing the laser 
   and odometry topic using the gmapping algoritm.

5. teleop_keyboard: This package is used to manually run the robot with keyboard keys. 


