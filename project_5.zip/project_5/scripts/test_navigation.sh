#!/bin/sh
xterm  -e  " roslaunch turtlebot robot.launch " &
sleep 5
xterm  -e  " roslaunch turtlebot amcl.launch " &
sleep 5
xterm  -e  " roslaunch turtlebot view_navigation.launch " &
sleep 5
