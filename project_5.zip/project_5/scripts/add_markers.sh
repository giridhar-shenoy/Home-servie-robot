#!/bin/sh
xterm  -e  " roslaunch turtlebot robot.launch " &
sleep 5
xterm  -e  " roslaunch turtlebot amcl.launch " &
sleep 5
xterm  -e  " roslaunch turtlebot view_navigation.launch " &
sleep 5
xterm  -e  " rosrun add_markers add_markers_alone " &
sleep 5
