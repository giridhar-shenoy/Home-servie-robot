#!/bin/sh
xterm  -e  " roslaunch turtlebot robot.launch " &
sleep 5
xterm  -e  " roslaunch turtlebot gmapping.launch " &
sleep 5
xterm  -e  " roslaunch turtlebot view_navigation.launch " &
sleep 5
xterm  -e  " rosrun teleop_twist_keyboard teleop_twist_keyboard.py " &
sleep 5
